import { i18n } from "../main.js";
import { ChatPortrait } from "./ChatPortrait.js";
import { MODULE_NAME } from "./settings.js";
export class ChatPortraitForm extends FormApplication {
    constructor(object, options = {}) {
        super(object, options);
    }
    /**
    * Default Options for this FormApplication
    */
    static get defaultOptions() {
        //@ts-ignore
        return mergeObject(super.defaultOptions, {
            title: i18n(MODULE_NAME + '.form-title'),
            id: 'chat-portrait-form',
            template: `modules/${MODULE_NAME}/templates/chat-portrait-form.html`,
            width: 500,
            closeOnSubmit: true,
            classes: ["sheet"]
        });
    }
    getData(options) {
        //@ts-ignore
        /*
        return mergeObject(super.getData(),{
                //@ts-ignore
                borderShapeList: {
                    'square': i18n(MODULE_NAME+'.square'),
                    'circle': i18n(MODULE_NAME+'.circle'),
                    'none': i18n(MODULE_NAME+'.none')
                }
            },
            this.reset ? ChatPortrait.defaultSettings :mergeObject(ChatPortrait.defaultSettings, game.settings.get(MODULE_NAME, 'settings'))
        );
        */
        const data = {
            borderShapeList: this.getSelectList(borderShapeListOptions, Settings.getBorderShape()),
            // ChatPortrait.defaultSettings
            useTokenImage: Settings.getUseTokenImage(),
            portraitSize: Settings.getPortraitSize(),
            //borderShape: this.getSelectList(borderShapeListOptions, Settings.getBorderShapeList()),
            useUserColorAsBorderColor: Settings.getUseUserColorAsBorderColor(),
            borderColor: Settings.getBorderColor(),
            borderWidth: Settings.getBorderWidth(),
            useUserColorAsChatBackgroundColor: Settings.getuseUserColorAsChatBackgroundColor(),
            useUserColorAsChatBorderColor: Settings.getuseUserColorAsChatBorderColor(),
            flavorNextToPortrait: Settings.getFlavorNextToPortrait(),
            forceNameSearch: Settings.getForceNameSearch()
        };
        return data;
    }
    activateListeners(html) {
        super.activateListeners(html);
        this.toggleBorderShape();
        this.toggleUseUserColorAsBorderColor();
        html.find('select[name="borderShape"]').change(this.toggleBorderShape.bind(this));
        html.find('input[name="useUserColorAsBorderColor"]').change(this.toggleUseUserColorAsBorderColor.bind(this));
        html.find('input[name="useUserColorAsBackgroundColor"]').change(this.toggleUseUserColorAsBackgroundColor.bind(this));
        html.find('button[name="reset"]').click(this.onReset.bind(this));
        this.reset = false;
    }
    toggleBorderShape() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBorderColor"]')[0].checked;
        $('input[name="useUserColorAsBorderColor"]').prop("disabled", noneBorder);
        $('input[name="useUserColorAsBackgroundColor"]').prop("disabled", noneBorder);
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderWidth"]').prop("disabled", noneBorder);
    }
    toggleUseUserColorAsBorderColor() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBorderColor"]')[0].checked;
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
    }
    toggleUseUserColorAsBackgroundColor() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBackgroundColor"]')[0].checked;
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
    }
    onReset() {
        this.reset = true;
        this.render();
    }
    /**
    * Executes on form submission.
    * @param {Object} event - the form submission event
    * @param {Object} formData - the form data
    */
    async _updateObject(event, formData) {
        let settings = mergeObject(ChatPortrait.settings, formData, {
            insertKeys: false,
            insertValues: false
        });
        await game.settings.set(MODULE_NAME, 'settings', settings);
    }
    getSelectList(myselectslist, selected) {
        let options = [];
        Object.keys(myselectslist).forEach((x, i) => {
            options.push({ value: x, selected: i == selected });
        });
        return options;
    }
}
export const borderShapeListOptions = {
    'square': i18n(MODULE_NAME + '.square'),
    'circle': i18n(MODULE_NAME + '.circle'),
    'none': i18n(MODULE_NAME + '.none')
};
/**
 * Provides functionality for interaction with module settings
 */
class Settings {
    //#region getters and setters
    // static getBorderShapeList() {
    //     return game.settings.get(MODULE_NAME, 'borderShapeList');
    // }
    static getUseTokenImage() {
        return game.settings.get(MODULE_NAME, 'useTokenImage');
    }
    static getPortraitSize() {
        return game.settings.get(MODULE_NAME, 'portraitSize');
    }
    static getBorderShape() {
        return game.settings.get(MODULE_NAME, 'borderShape');
    }
    static getUseUserColorAsBorderColor() {
        return game.settings.get(MODULE_NAME, 'useUserColorAsBorderColor');
    }
    static getBorderColor() {
        return game.settings.get(MODULE_NAME, 'borderColor');
    }
    static getBorderWidth() {
        return game.settings.get(MODULE_NAME, 'borderWidth');
    }
    static getuseUserColorAsChatBackgroundColor() {
        return game.settings.get(MODULE_NAME, 'userColorAsChatBackgroundColor');
    }
    static getuseUserColorAsChatBorderColor() {
        return game.settings.get(MODULE_NAME, 'useUserColorAsChatBorderColor');
    }
    static getFlavorNextToPortrait() {
        return game.settings.get(MODULE_NAME, 'flavorNextToPortrait');
    }
    static getForceNameSearch() {
        return game.settings.get(MODULE_NAME, 'forceNameSearch');
    }
}
