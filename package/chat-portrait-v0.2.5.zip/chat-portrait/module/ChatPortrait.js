import { ChatLink } from "./chatlink.js";
import { SettingsForm } from "./ChatPortraitForm.js";
import { getCanvas } from "./settings.js";
/**
 * Main class wrapper for all of our features.
 */
export class ChatPortrait {
    /**
     * @param  {ChatMessage} chatMessage
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     */
    static onRenderChatMessage(chatMessage, html, speakerInfo) {
        const messageData = speakerInfo;
        // const speaker: {
        //     scene?: string;
        //     actor?: string;
        //     token?: string;
        //     alias?: string;
        // } = messageData.message.speaker;
        // const imgPath: string = ChatPortrait.loadActorImagePathForChatMessage(speaker);
        const imgPath = ChatPortrait.loadActorImagePathForChatMessage(speakerInfo.message);
        if (imgPath) {
            const imgElement = ChatPortrait.generatePortraitImageElement(imgPath);
            const authorColor = messageData.author ? messageData.author.data.color : 'black';
            ChatPortrait.setImageBorder(imgElement, authorColor);
            // Place the image to left of the header by injecting the HTML
            const element = html.find('.message-header')[0];
            element.prepend(imgElement);
            if (messageData.message.flavor && ChatPortrait.settings.flavorNextToPortrait) {
                if (messageData.message.flavor && ChatPortrait.settings.flavorNextToPortrait) {
                    const flavorElement = html.find('.flavor-text');
                    if (flavorElement.length > 0) {
                        const copiedElement = flavorElement[0].cloneNode(true);
                        flavorElement.remove();
                        const brElement = document.createElement('br');
                        const senderElement = html.find('.message-sender')[0];
                        senderElement.appendChild(brElement);
                        senderElement.appendChild(copiedElement);
                    }
                }
            }
            // Add click listener to image
            ChatLink.prepareEventImage(chatMessage, html, speakerInfo);
            // Update size item image by settings
            const elementItemList = html.find('.item-card img');
            if (elementItemList.length > 0 && ChatPortrait.settings.portraitSizeItem != 36) {
                for (let i = 0; i < elementItemList.length; i++) {
                    const elementItem = elementItemList[0];
                    const size = ChatPortrait.settings.portraitSizeItem;
                    elementItem.width = size;
                    elementItem.height = size;
                }
            }
            ChatPortrait.setChatMessageBackground(html, messageData, authorColor);
            ChatPortrait.setChatMessageBorder(html, messageData, authorColor);
        }
    }
    /**
     * Load the appropriate actor image path for a given message, leveraging token or actor or actor search.
     * @param  {{scene?:string;actor?:string;token?:string;alias?:string;}} speaker
     * @returns string
     */
    //static loadActorImagePathForChatMessage(speaker: {scene?: string;actor?: string;token?: string;alias?: string; }): string {
    static loadActorImagePathForChatMessage(message) {
        const speaker = message.speaker;
        if (speaker) {
            if (!speaker.token && !speaker.actor) {
                return "icons/svg/mystery-man.svg";
            }
            const useTokenImage = this.settings.useTokenImage;
            let actor;
            if (speaker.token) {
                actor = game.actors.tokens[speaker.token];
                if (!actor) {
                    //const tokenData = game.scenes.get(speaker.scene)?.data?.tokens?.find(t => t._id === speaker.token); // Deprecated on 0.8.6
                    //@ts-ignore
                    const token = getCanvas()?.tokens?.getDocuments().get(speaker.token);
                    const tokenData = token.data;
                    if (useTokenImage && tokenData?.img) {
                        return tokenData.img;
                    }
                    else if (!useTokenImage && tokenData?.actorData?.img) {
                        return tokenData.actorData.img;
                    }
                }
            }
            if (!actor) {
                //actor = game.actors.get(speaker.actor); // Deprecated on 0.8.6
                actor = Actors.instance.get(speaker.actor);
            }
            const forceNameSearch = this.settings.forceNameSearch;
            if (!actor && forceNameSearch) {
                actor = game.actors.find((a) => a.name === speaker.alias);
            }
            return useTokenImage ? actor?.data?.token?.img : actor.data.img; // actor?.img; // Deprecated on 0.8.6
        }
        return "icons/svg/mystery-man.svg";
    }
    /**
     * Generate portrait HTML Image Element to insert into chat messages.
     * @param  {string} imgPath
     * @returns HTMLImageElement
     */
    static generatePortraitImageElement(imgPath) {
        if (!imgPath) {
            return;
        }
        const img = document.createElement('img');
        img.src = imgPath;
        const size = this.settings.portraitSize;
        img.width = size;
        img.height = size;
        img.classList.add("message-portrait");
        return img;
    }
    /**
     * Set portrait image border shape
     * @param  {HTMLImageElement} img
     * @param  {string} authorColor
     */
    static setImageBorder(img, authorColor) {
        const borderShape = this.settings.borderShape;
        const borderWidth = this.settings.borderWidth;
        const borderColor = this.settings.useUserColorAsBorderColor ? authorColor : this.settings.borderColor;
        switch (borderShape) {
            case 'square':
                img.style.border = `${borderWidth}px solid ${borderColor}`;
                break;
            case 'circle':
                img.style.border = `${borderWidth}px solid ${borderColor}`;
                img.style.borderRadius = '50%';
                break;
            case 'none':
                img.style.border = 'none';
                break;
        }
    }
    /**
     * Set the background color of the entire message to be the color for the author.
     * Only do so if
     *  - chatBackgroundColor setting is true AND
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     * @param  {string} authorColor
     */
    static setChatMessageBackground(html, messageData, authorColor) {
        const useUserBackgroundColor = this.settings.useUserColorAsChatBackgroundColor;
        if (useUserBackgroundColor) {
            html[0].setAttribute('style', 'background-color:' + authorColor + ';background-blend-mode:screen;');
        }
    }
    /**
     * Set the border color of the entire message to be the color for the author.
     * Only do so if
     *  - chatBorderColor setting is true AND
     *  - someone further up the chain hasn't already changed the color
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     * @param  {string} authorColor
     */
    static setChatMessageBorder(html, messageData, authorColor) {
        const useUserBorderColor = this.settings.useUserColorAsChatBorderColor;
        // only override the border color if someone further up the chain hasn't already done so.
        if (useUserBorderColor && !messageData.borderColor) {
            html[0].style.borderColor = authorColor;
            messageData.borderColor = authorColor;
        }
    }
    static get settings() {
        //return mergeObject(this.defaultSettings, <ChatPortraitSettings>game.settings.get(MODULE_NAME, 'settings'));
        //return mergeObject(this.defaultSettings,{
        return {
            //borderShapeList: Settings.getBorderShapeList(),
            useTokenImage: SettingsForm.getUseTokenImage(),
            portraitSize: SettingsForm.getPortraitSize(),
            portraitSizeItem: SettingsForm.getPortraitSizeItem(),
            borderShape: SettingsForm.getBorderShape(),
            useUserColorAsBorderColor: SettingsForm.getUseUserColorAsBorderColor(),
            borderColor: SettingsForm.getBorderColor(),
            borderWidth: SettingsForm.getBorderWidth(),
            useUserColorAsChatBackgroundColor: SettingsForm.getUseUserColorAsChatBackgroundColor(),
            useUserColorAsChatBorderColor: SettingsForm.getUseUserColorAsChatBorderColor(),
            flavorNextToPortrait: SettingsForm.getFlavorNextToPortrait(),
            forceNameSearch: SettingsForm.getForceNameSearch(),
            hoverTooltip: SettingsForm.getHoverTooltip(),
        };
    }
    /**
     * Get default settings object.
     * @returns ChatPortraitSetting
     */
    static get defaultSettings() {
        return {
            useTokenImage: false,
            portraitSize: 36,
            portraitSizeItem: 36,
            borderShape: 'square',
            useUserColorAsBorderColor: true,
            borderColor: '#000000',
            borderWidth: 2,
            useUserColorAsChatBackgroundColor: false,
            useUserColorAsChatBorderColor: false,
            flavorNextToPortrait: false,
            forceNameSearch: false,
            hoverTooltip: false
        };
    }
}
