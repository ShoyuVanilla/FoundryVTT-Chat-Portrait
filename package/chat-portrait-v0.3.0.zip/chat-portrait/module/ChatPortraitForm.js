import { i18n } from "../main.js";
import { MODULE_NAME } from "./settings.js";
export class ChatPortraitForm extends FormApplication {
    constructor(object, options = {}) {
        super(object, options);
        this.borderShapeListOptions = {
            'square': i18n(MODULE_NAME + '.square'),
            'circle': i18n(MODULE_NAME + '.circle'),
            'none': i18n(MODULE_NAME + '.none')
        };
        this.displaySettingListOptions = {
            'allCards': i18n(MODULE_NAME + '.displaySetting.choice.allCards'),
            'selfAndGM': i18n(MODULE_NAME + '.displaySetting.choice.selfAndGM'),
            'self': i18n(MODULE_NAME + '.displaySetting.choice.self'),
            'gm': i18n(MODULE_NAME + '.displaySetting.choice.gm'),
            'player': i18n(MODULE_NAME + '.displaySetting.choice.player'),
            'none': i18n(MODULE_NAME + '.displaySetting.choice.none'), //"Don't affect any messages.",
        };
        this.displayUnknownListOptions = {
            'allCards': i18n(MODULE_NAME + '.displayUnknown.choice.allCards'),
            'selfAndGM': i18n(MODULE_NAME + '.displayUnknown.choice.selfAndGM'),
            'self': i18n(MODULE_NAME + '.displayUnknown.choice.self'),
            'gm': i18n(MODULE_NAME + '.displayUnknown.choice.gm'),
            'player': i18n(MODULE_NAME + '.displayUnknown.choice.player'),
            'none': i18n(MODULE_NAME + '.displayUnknown.choice.none'),
            'onlyNpc': i18n(MODULE_NAME + '.displayUnknown.choice.onlyNpc'), //"Affect any messages done from a NPC (need a compatible system with the 'npc' type like D&D5)."
        };
    }
    /**
    * Default Options for this FormApplication
    */
    static get defaultOptions() {
        //@ts-ignore
        return mergeObject(super.defaultOptions, {
            title: i18n(MODULE_NAME + '.form-title'),
            id: 'chat-portrait-form',
            template: `modules/${MODULE_NAME}/templates/chat-portrait-form.html`,
            width: 500,
            closeOnSubmit: true,
            classes: ["sheet"]
        });
    }
    getData(options) {
        //@ts-ignore
        /*
        return mergeObject(super.getData(),{
                //@ts-ignore
                borderShapeList: {
                    'square': i18n(MODULE_NAME+'.square'),
                    'circle': i18n(MODULE_NAME+'.circle'),
                    'none': i18n(MODULE_NAME+'.none')
                }
            },
            this.reset ? ChatPortrait.defaultSettings :mergeObject(ChatPortrait.defaultSettings, game.settings.get(MODULE_NAME, 'settings'))
        );
        */
        let data;
        if (this.reset) {
            data = {
                borderShapeList: this.getSelectList(this.borderShapeListOptions, 'square'),
                useTokenImage: false,
                useTokenName: false,
                portraitSize: 36,
                portraitSizeItem: 36,
                //borderShape: 'square',
                useUserColorAsBorderColor: true,
                borderColor: '#000000',
                borderWidth: 2,
                useUserColorAsChatBackgroundColor: false,
                useUserColorAsChatBorderColor: false,
                flavorNextToPortrait: false,
                forceNameSearch: false,
                hoverTooltip: false,
                textSizeName: 0,
                displaySettingList: this.getSelectList(this.displaySettingListOptions, 'allCards'),
                useAvatarImage: false,
                displayUnknownList: this.getSelectList(this.displayUnknownListOptions, 'none'),
                displayUnknownPlaceHolderActorName: 'Unknown Actor',
                displayUnknownPlaceHolderItemName: 'Unknown Item',
                displayUnknownPlaceHolderItemIcon: `/modules/${MODULE_NAME}/assets/inv-unidentified.png`,
                displaySettingOTHER: true,
                displaySettingOOC: true,
                displaySettingIC: true,
                displaySettingEMOTE: true,
                displaySettingWHISPER: true,
                displaySettingROLL: true,
                displaySettingWhisperToOther: false,
            };
        }
        else {
            data = {
                borderShapeList: this.getSelectList(this.borderShapeListOptions, SettingsForm.getBorderShape()),
                useTokenImage: SettingsForm.getUseTokenImage(),
                useTokenName: SettingsForm.getUseTokenName(),
                portraitSize: SettingsForm.getPortraitSize(),
                portraitSizeItem: SettingsForm.getPortraitSizeItem(),
                //borderShape: this.getSelectList(borderShapeListOptions, Settings.getBorderShapeList()),
                useUserColorAsBorderColor: SettingsForm.getUseUserColorAsBorderColor(),
                borderColor: SettingsForm.getBorderColor(),
                borderWidth: SettingsForm.getBorderWidth(),
                useUserColorAsChatBackgroundColor: SettingsForm.getUseUserColorAsChatBackgroundColor(),
                useUserColorAsChatBorderColor: SettingsForm.getUseUserColorAsChatBorderColor(),
                flavorNextToPortrait: SettingsForm.getFlavorNextToPortrait(),
                forceNameSearch: SettingsForm.getForceNameSearch(),
                hoverTooltip: SettingsForm.getHoverTooltip(),
                textSizeName: SettingsForm.getTextSizeName(),
                displaySettingList: this.getSelectList(this.displaySettingListOptions, SettingsForm.getDisplaySetting()),
                useAvatarImage: SettingsForm.getUseAvatarImage(),
                displayUnknownList: this.getSelectList(this.displayUnknownListOptions, SettingsForm.getDisplayUnknown()),
                displayUnknownPlaceHolderActorName: SettingsForm.getDisplayUnknownPlaceHolderActorName(),
                displayUnknownPlaceHolderItemName: SettingsForm.getDisplayUnknownPlaceHolderItemName(),
                displayUnknownPlaceHolderItemIcon: SettingsForm.getDisplayUnknownPlaceHolderItemIcon(),
                displaySettingOTHER: SettingsForm.getDisplaySettingOTHER(),
                displaySettingOOC: SettingsForm.getDisplaySettingOOC(),
                displaySettingIC: SettingsForm.getDisplaySettingIC(),
                displaySettingEMOTE: SettingsForm.getDisplaySettingEMOTE(),
                displaySettingWHISPER: SettingsForm.getDisplaySettingWHISPER(),
                displaySettingROLL: SettingsForm.getDisplaySettingROLL(),
                displaySettingWhisperToOther: SettingsForm.getDisplaySettingWhisperToOther(),
            };
        }
        return data;
    }
    activateListeners(html) {
        super.activateListeners(html);
        this.toggleBorderShape();
        this.toggleUseUserColorAsBorderColor();
        html.find('select[name="borderShape"]').change(this.toggleBorderShape.bind(this));
        html.find('input[name="useUserColorAsBorderColor"]').change(this.toggleUseUserColorAsBorderColor.bind(this));
        html.find('input[name="useUserColorAsBackgroundColor"]').change(this.toggleUseUserColorAsBackgroundColor.bind(this));
        html.find('button[name="reset"]').click(this.onReset.bind(this));
        this.reset = false;
    }
    toggleBorderShape() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBorderColor"]')[0].checked;
        $('input[name="useUserColorAsBorderColor"]').prop("disabled", noneBorder);
        $('input[name="useUserColorAsBackgroundColor"]').prop("disabled", noneBorder);
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderWidth"]').prop("disabled", noneBorder);
    }
    toggleUseUserColorAsBorderColor() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBorderColor"]')[0].checked;
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
    }
    toggleUseUserColorAsBackgroundColor() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBackgroundColor"]')[0].checked;
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
    }
    onReset() {
        this.reset = true;
        this.render();
    }
    /**
    * Executes on form submission.
    * @param {Object} event - the form submission event
    * @param {Object} formData - the form data
    */
    async _updateObject(event, formData) {
        // let settings = mergeObject(ChatPortrait.settings, formData,
        //     {
        //         insertKeys: false,
        //         insertValues: false
        //     });
        // await game.settings.set(MODULE_NAME, 'settings', settings);
        SettingsForm.setUseTokenImage(formData.useTokenImage);
        SettingsForm.setUseTokenName(formData.useTokenName);
        SettingsForm.setPortraitSize(formData.portraitSize);
        SettingsForm.setPortraitSizeItem(formData.portraitSizeItem);
        SettingsForm.setBorderShape(formData.borderShape);
        SettingsForm.setUseUserColorAsBorderColor(formData.useUserColorAsBorderColor);
        SettingsForm.setBorderColor(formData.borderColor);
        SettingsForm.setBorderWidth(formData.borderWidth);
        SettingsForm.setUseUserColorAsChatBackgroundColor(formData.useUserColorAsChatBackgroundColor);
        SettingsForm.setUseUserColorAsChatBorderColor(formData.useUserColorAsChatBorderColor);
        SettingsForm.setFlavorNextToPortrait(formData.flavorNextToPortrait);
        SettingsForm.setForceNameSearch(formData.forceNameSearch);
        SettingsForm.setHoverTooltip(formData.hoverTooltip);
        SettingsForm.setTextSizeName(formData.textSizeName);
        SettingsForm.setDisplaySetting(formData.displaySetting);
        SettingsForm.setUseAvatarImage(formData.useAvatarImage);
        SettingsForm.setDisplayUnknown(formData.displayUnknown);
        SettingsForm.setDisplayUnknownPlaceHolderActorName(formData.displayUnknownPlaceHolderActorName);
        SettingsForm.setDisplayUnknownPlaceHolderItemName(formData.displayUnknownPlaceHolderItemName);
        SettingsForm.setDisplayUnknownPlaceHolderItemIcon(formData.displayUnknownPlaceHolderItemIcon);
        SettingsForm.setDisplaySettingOTHER(formData.displaySettingOTHER);
        SettingsForm.setDisplaySettingOOC(formData.displaySettingOOC);
        SettingsForm.setDisplaySettingIC(formData.displaySettingIC);
        SettingsForm.setDisplaySettingEMOTE(formData.displaySettingEMOTE);
        SettingsForm.setDisplaySettingWHISPER(formData.displaySettingWHISPER);
        SettingsForm.setDisplaySettingROLL(formData.displaySettingROLL);
        SettingsForm.setDisplaySettingWhisperToOther(formData.displaySettingWhisperToOther);
    }
    getSelectList(myselectslist, selected) {
        let options = [];
        Object.keys(myselectslist).forEach((x, i) => {
            options.push({ value: x, selected: x == selected });
        });
        return options;
    }
}
/**
 * Provides functionality for interaction with module settings
 */
export class SettingsForm {
    //#region getters and setters
    // static getBorderShapeList() {
    //     return game.settings.get(MODULE_NAME, 'borderShapeList');
    // }
    static getUseTokenImage() {
        return game.settings.get(MODULE_NAME, 'useTokenImage');
    }
    static setUseTokenImage(value) {
        game.settings.set(MODULE_NAME, 'useTokenImage', value);
    }
    static getUseTokenName() {
        return game.settings.get(MODULE_NAME, 'useTokenName');
    }
    static setUseTokenName(value) {
        game.settings.set(MODULE_NAME, 'useTokenName', value);
    }
    static getPortraitSize() {
        return game.settings.get(MODULE_NAME, 'portraitSize');
    }
    static setPortraitSize(value) {
        game.settings.set(MODULE_NAME, 'portraitSize', value);
    }
    static getPortraitSizeItem() {
        return game.settings.get(MODULE_NAME, 'portraitSizeItem');
    }
    static setPortraitSizeItem(value) {
        game.settings.set(MODULE_NAME, 'portraitSizeItem', value);
    }
    static getBorderShape() {
        return game.settings.get(MODULE_NAME, 'borderShape');
    }
    static setBorderShape(value) {
        game.settings.set(MODULE_NAME, 'borderShape', value);
    }
    static getUseUserColorAsBorderColor() {
        return game.settings.get(MODULE_NAME, 'useUserColorAsBorderColor');
    }
    static setUseUserColorAsBorderColor(value) {
        game.settings.set(MODULE_NAME, 'useUserColorAsBorderColor', value);
    }
    static getBorderColor() {
        return game.settings.get(MODULE_NAME, 'borderColor');
    }
    static setBorderColor(value) {
        game.settings.set(MODULE_NAME, 'borderColor', value);
    }
    static getBorderWidth() {
        return game.settings.get(MODULE_NAME, 'borderWidth');
    }
    static setBorderWidth(value) {
        game.settings.set(MODULE_NAME, 'borderWidth', value);
    }
    static getUseUserColorAsChatBackgroundColor() {
        return game.settings.get(MODULE_NAME, 'useUserColorAsChatBackgroundColor');
    }
    static setUseUserColorAsChatBackgroundColor(value) {
        game.settings.set(MODULE_NAME, 'useUserColorAsChatBackgroundColor', value);
    }
    static getUseUserColorAsChatBorderColor() {
        return game.settings.get(MODULE_NAME, 'useUserColorAsChatBorderColor');
    }
    static setUseUserColorAsChatBorderColor(value) {
        game.settings.set(MODULE_NAME, 'useUserColorAsChatBorderColor', value);
    }
    static getFlavorNextToPortrait() {
        return game.settings.get(MODULE_NAME, 'flavorNextToPortrait');
    }
    static setFlavorNextToPortrait(value) {
        game.settings.set(MODULE_NAME, 'flavorNextToPortrait', value);
    }
    static getForceNameSearch() {
        return game.settings.get(MODULE_NAME, 'forceNameSearch');
    }
    static setForceNameSearch(value) {
        game.settings.set(MODULE_NAME, 'forceNameSearch', value);
    }
    static getHoverTooltip() {
        return game.settings.get(MODULE_NAME, 'hoverTooltip');
    }
    static setHoverTooltip(value) {
        game.settings.set(MODULE_NAME, 'hoverTooltip', value);
    }
    static getTextSizeName() {
        return game.settings.get(MODULE_NAME, 'textSizeName');
    }
    static setTextSizeName(value) {
        game.settings.set(MODULE_NAME, 'textSizeName', value);
    }
    static getDisplaySetting() {
        return game.settings.get(MODULE_NAME, 'displaySetting');
    }
    static setDisplaySetting(value) {
        game.settings.set(MODULE_NAME, 'displaySetting', value);
    }
    static getUseAvatarImage() {
        return game.settings.get(MODULE_NAME, 'useAvatarImage');
    }
    static setUseAvatarImage(value) {
        game.settings.set(MODULE_NAME, 'useAvatarImage', value);
    }
    static getDisplayUnknown() {
        return game.settings.get(MODULE_NAME, 'displayUnknown');
    }
    static setDisplayUnknown(value) {
        game.settings.set(MODULE_NAME, 'displayUnknown', value);
    }
    static getDisplayUnknownPlaceHolderActorName() {
        return game.settings.get(MODULE_NAME, 'displayUnknownPlaceHolderActorName');
    }
    static setDisplayUnknownPlaceHolderActorName(value) {
        game.settings.set(MODULE_NAME, 'displayUnknownPlaceHolderActorName', value);
    }
    static getDisplayUnknownPlaceHolderItemName() {
        return game.settings.get(MODULE_NAME, 'displayUnknownPlaceHolderItemName');
    }
    static setDisplayUnknownPlaceHolderItemName(value) {
        game.settings.set(MODULE_NAME, 'displayUnknownPlaceHolderItemName', value);
    }
    static getDisplayUnknownPlaceHolderItemIcon() {
        return game.settings.get(MODULE_NAME, 'displayUnknownPlaceHolderItemIcon');
    }
    static setDisplayUnknownPlaceHolderItemIcon(value) {
        game.settings.set(MODULE_NAME, 'displayUnknownPlaceHolderItemIcon', value);
    }
    static getDisplaySettingOTHER() {
        return game.settings.get(MODULE_NAME, 'displaySettingOTHER');
    }
    static setDisplaySettingOTHER(value) {
        game.settings.set(MODULE_NAME, 'displaySettingOTHER', value);
    }
    static getDisplaySettingOOC() {
        return game.settings.get(MODULE_NAME, 'displaySettingOOC');
    }
    static setDisplaySettingOOC(value) {
        game.settings.set(MODULE_NAME, 'displaySettingOOC', value);
    }
    static getDisplaySettingIC() {
        return game.settings.get(MODULE_NAME, 'displaySettingIC');
    }
    static setDisplaySettingIC(value) {
        game.settings.set(MODULE_NAME, 'displaySettingIC', value);
    }
    static getDisplaySettingEMOTE() {
        return game.settings.get(MODULE_NAME, 'displaySettingEMOTE');
    }
    static setDisplaySettingEMOTE(value) {
        game.settings.set(MODULE_NAME, 'displaySettingEMOTE', value);
    }
    static getDisplaySettingWHISPER() {
        return game.settings.get(MODULE_NAME, 'displaySettingWHISPER');
    }
    static setDisplaySettingWHISPER(value) {
        game.settings.set(MODULE_NAME, 'displaySettingWHISPER', value);
    }
    static getDisplaySettingROLL() {
        return game.settings.get(MODULE_NAME, 'displaySettingROLL');
    }
    static setDisplaySettingROLL(value) {
        game.settings.set(MODULE_NAME, 'displaySettingROLL', value);
    }
    static getDisplaySettingWhisperToOther() {
        return game.settings.get(MODULE_NAME, 'displaySettingWhisperToOther');
    }
    static setDisplaySettingWhisperToOther(value) {
        game.settings.set(MODULE_NAME, 'displaySettingWhisperToOther', value);
    }
}
