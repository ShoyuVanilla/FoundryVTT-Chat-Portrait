import { warn } from "../main.js";
import { ChatLink } from "./chatlink.js";
import { SettingsForm } from "./ChatPortraitForm.js";
import { ImageReplacerImpl } from "./ImageReplacer.js";
import { getCanvas, MODULE_NAME } from "./settings.js";
/**
 * Main class wrapper for all of our features.
 */
export class ChatPortrait {
    /**
     * @param  {ChatMessage} chatMessage
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     */
    static onRenderChatMessage(chatMessage, html, speakerInfo, imageReplacer) {
        if (!ChatPortrait.shouldOverrideMessageStyling(speakerInfo)) {
            // Do not style this
            return;
        }
        if (!this.settings.displaySettingWhisperToOther && ChatPortrait.isWhisperToOther(speakerInfo)) {
            // Don't update whispers that the current player isn't privy to
            return;
        }
        let messageType = ChatPortrait.getMessageTypeVisible(speakerInfo);
        if (!this.settings.displaySettingOTHER && messageType == CONST.CHAT_MESSAGE_TYPES.OTHER) {
            return;
        }
        if (!this.settings.displaySettingOOC && messageType == CONST.CHAT_MESSAGE_TYPES.OOC) {
            return;
        }
        if (!this.settings.displaySettingIC && messageType == CONST.CHAT_MESSAGE_TYPES.IC) {
            return;
        }
        if (!this.settings.displaySettingEMOTE && messageType == CONST.CHAT_MESSAGE_TYPES.EMOTE) {
            return;
        }
        if (!this.settings.displaySettingWHISPER && messageType == CONST.CHAT_MESSAGE_TYPES.WHISPER) {
            return;
        }
        if (!this.settings.displaySettingROLL && messageType == CONST.CHAT_MESSAGE_TYPES.ROLL) {
            return;
        }
        let senderElement;
        let elementItemImageList;
        let elementItemNameList;
        let elementItemContentList;
        let elementItemTextList;
        // GET Image, Text, Content of the item card by system used
        if (game.system.id === 'dnd5e') {
            senderElement = html.find('.message-sender')[0];
            // Bug fix plutonium
            senderElement.style.display = 'block';
            elementItemImageList = html.find('.item-card img');
            elementItemNameList = html.find('.item-card .item-name'); // work only with dnd5e
            //elementItemNameList = html.find('.item-card h3'); // work with more system ?
            elementItemContentList = html.find('.item-card .card-content');
            elementItemTextList = html.find('.message-header .flavor-text');
        }
        else if (game.system.id === 'shadowrun5e') {
            senderElement = html.find('.message-sender')[0];
            // Bug fix plutonium
            senderElement.style.display = 'block';
            elementItemImageList = html.find('.message-content img');
            elementItemNameList = html.find('.message-content h3'); // work with more system ?
            elementItemContentList = html.find('.message-content .card-main-content');
            elementItemTextList = html.find('.message-header .flavor-text');
        }
        //   else if (game.system.id === 'D35E') {
        //     // TODO
        //   }
        //   else if (game.system.id === 'pf2e') {
        //     // TODO
        //   }
        else {
            warn(`System ${game.system.id} have not been implemented and therefore might not work properly.`);
            // BY DEFAULT DND5e Style
            senderElement = html.find('.message-sender')[0];
            // Bug fix plutonium
            senderElement.style.display = 'block';
            elementItemImageList = html.find('.item-card img');
            elementItemNameList = html.find('.item-card .item-name'); // work only with dnd5e
            //elementItemNameList = html.find('.item-card h3'); // work with more system ?
            elementItemContentList = html.find('.item-card .card-content');
            elementItemTextList = html.find('message-header flavor-text');
        }
        ChatPortrait.onRenderChatMessageInternal(chatMessage, html, speakerInfo, senderElement, elementItemImageList, elementItemNameList, elementItemContentList, elementItemTextList, imageReplacer);
    }
    /**
     * @param  {ChatMessage} chatMessage
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     */
    static onRenderChatMessageInternal(chatMessage, html, speakerInfo, senderElement, elementItemImageList, elementItemNameList, elementItemContentList, elementItemTextList, imageReplacer) {
        const messageData = speakerInfo;
        let imgPath;
        const authorColor = messageData.author ? messageData.author.data.color : 'black';
        //const speaker = speakerInfo.message.speaker;
        const useTokenName = this.settings.useTokenName;
        if (useTokenName) {
            ChatPortrait.replaceSenderWithTokenName(senderElement, speakerInfo);
        }
        if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
            imgPath = "icons/svg/mystery-man.svg";
        }
        else {
            imgPath = ChatPortrait.loadActorImagePathForChatMessage(speakerInfo.message);
        }
        //@ts-ignore
        const imgElement = ChatPortrait.generatePortraitImageElement(imgPath)
            .then((imgElement) => {
            ChatPortrait.setImageBorder(imgElement, authorColor);
            // Place the image to left of the header by injecting the HTML
            const element = html.find('.message-header')[0];
            element.prepend(imgElement);
            /*
            const senderElement: HTMLElement = html.find('.message-sender')[0];
            // Bug fix plutonium
            senderElement.style.display = 'block';
            const elementItemImageList = html.find('.item-card img');
            //const elementItemNameList = html.find('.item-card .item-name'); // work only with dnd5e
            const elementItemNameList = html.find('.item-card h3'); // work with more system ?
            const elementItemContentList = html.find('.item-card .card-content');
            */
            if (messageData.message.flavor && ChatPortrait.settings.flavorNextToPortrait) {
                const flavorElement = html.find('.flavor-text');
                if (flavorElement.length > 0) {
                    const copiedElement = flavorElement[0].cloneNode(true);
                    flavorElement.remove();
                    const brElement = document.createElement('br');
                    const senderElement = html.find('.message-sender')[0];
                    senderElement.appendChild(brElement);
                    senderElement.appendChild(copiedElement);
                }
            }
            // Update size text name by settings
            if (ChatPortrait.settings.textSizeName > 0) {
                const size = ChatPortrait.settings.textSizeName;
                senderElement.style.fontSize = size + 'px';
                if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
                    senderElement.innerText = this.settings.displayUnknownPlaceHolderActorName; //'Unknown Actor';
                }
            }
            else if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
                senderElement.innerText = this.settings.displayUnknownPlaceHolderActorName; //'Unknown Actor';
            }
            // Add click listener to image and text
            ChatLink.prepareEventImage(chatMessage, html, speakerInfo);
            // Update size item image by settings
            if (elementItemImageList.length > 0 && ChatPortrait.settings.portraitSizeItem != 36 && ChatPortrait.settings.portraitSizeItem > 0) {
                for (let i = 0; i < elementItemImageList.length; i++) {
                    const elementItemImage = elementItemImageList[i];
                    const size = ChatPortrait.settings.portraitSizeItem;
                    elementItemImage.width = size;
                    elementItemImage.height = size;
                    if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
                        elementItemImage.src = this.settings.displayUnknownPlaceHolderItemIcon; //`/modules/${MODULE_NAME}/assets/inv-unidentified.png`;
                    }
                }
            }
            else if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
                for (let i = 0; i < elementItemImageList.length; i++) {
                    const elementItemImage = elementItemImageList[i];
                    elementItemImage.src = this.settings.displayUnknownPlaceHolderItemIcon; //`/modules/${MODULE_NAME}/assets/inv-unidentified.png`;
                }
            }
            // Update hide info about the weapon
            if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
                for (let i = 0; i < elementItemNameList.length; i++) {
                    const elementItemName = elementItemNameList[i];
                    elementItemName.innerText = this.settings.displayUnknownPlaceHolderItemName; //'Unknown Weapon';
                }
                for (let i = 0; i < elementItemContentList.length; i++) {
                    const elementItemContent = elementItemContentList[i];
                    elementItemContent.innerText = this.settings.displayUnknownPlaceHolderItemName; //'Unknown Weapon';
                }
            }
            // Check for Ability/Skills/Tools/Saving Throw for avoid the double portrait
            if (elementItemNameList.length > 0) {
                for (let i = 0; i < elementItemNameList.length; i++) {
                    const elementItemName = elementItemNameList[i];
                    elementItemName.style.display = 'flex';
                    if (elementItemName) {
                        const value = ImageReplacerImpl[elementItemName.innerText];
                        if (value) {
                            if (elementItemImageList.length > 0) {
                                const elementItemImage = elementItemImageList[i];
                                elementItemImage.src = value;
                                elementItemName.prepend(elementItemImage);
                            }
                            else {
                                const elementItemImage = document.createElement("img");
                                const size = ChatPortrait.settings.portraitSizeItem;
                                elementItemImage.width = size;
                                elementItemImage.height = size;
                                elementItemImage.src = value;
                                elementItemName.prepend(elementItemImage);
                            }
                        }
                    }
                }
            }
            else {
                for (let i = 0; i < elementItemTextList.length; i++) {
                    const elementItemText = elementItemTextList[i];
                    elementItemText.style.display = 'flex';
                    const value = ImageReplacerImpl[elementItemText.innerText];
                    if (value) {
                        if (elementItemImageList.length > 0) {
                            const elementItemImage = elementItemImageList[i];
                            elementItemImage.src = value;
                            elementItemText.prepend(elementItemImage);
                        }
                        else {
                            const elementItemImage = document.createElement("img");
                            const size = ChatPortrait.settings.portraitSizeItem;
                            elementItemImage.width = size;
                            elementItemImage.height = size;
                            elementItemImage.src = value;
                            elementItemText.prepend(elementItemImage);
                        }
                    }
                    if (ChatPortrait.shouldOverrideMessageUnknown(messageData)) {
                        elementItemText.innerText = this.settings.displayUnknownPlaceHolderItemName;
                    }
                }
            }
            ChatPortrait.setChatMessageBackground(html, messageData, authorColor);
            ChatPortrait.setChatMessageBorder(html, messageData, authorColor);
            if (this.settings.displayPlayerName) {
                ChatPortrait.appendPlayerName(senderElement, speakerInfo.author);
            }
        });
    }
    /**
     * Load the appropriate actor image path for a given message, leveraging token or actor or actor search.
     * @param  {{scene?:string;actor?:string;token?:string;alias?:string;}} speaker
     * @returns string
     */
    //static loadActorImagePathForChatMessage(speaker: {scene?: string;actor?: string;token?: string;alias?: string; }): string {
    static loadActorImagePathForChatMessage(message) {
        const speaker = message.speaker;
        if (speaker) {
            if (!speaker.token && !speaker.actor) {
                if (message.user && this.settings.useAvatarImage && !ChatPortrait.isSpeakerGM(message)) {
                    const imgAvatar = ChatPortrait.getUserAvatar(message);
                    if (imgAvatar && !imgAvatar.includes("mystery-man")) {
                        return imgAvatar;
                    }
                    else {
                        return "icons/svg/mystery-man.svg";
                    }
                }
                else {
                    return "icons/svg/mystery-man.svg";
                }
            }
            // It's a chat message associated with an actor
            const useTokenImage = this.settings.useTokenImage;
            const actor = ChatPortrait.getActor(speaker);
            // Make sense only for player and for non GM
            if (actor?.data?.type == "character" && this.settings.useAvatarImage && !ChatPortrait.isSpeakerGM(message)) {
                const imgAvatar = ChatPortrait.getUserAvatar(message);
                if (imgAvatar && !imgAvatar.includes("mystery-man")) {
                    return imgAvatar;
                }
            }
            if (speaker.token && !actor) {
                //@ts-ignore
                let token = getCanvas()?.tokens?.getDocuments().get(speaker.token);
                if (!token) {
                    token = game.scenes.get(speaker.scene)?.data?.tokens?.find(t => t._id === speaker.token); // Deprecated on 0.8.6
                }
                if (token) {
                    const tokenData = token.data;
                    if (useTokenImage && tokenData?.img) {
                        return tokenData.img;
                    }
                    else if (!useTokenImage && tokenData?.actorData?.img) {
                        return tokenData.actorData.img;
                    }
                }
            }
            return useTokenImage ? actor?.data?.token?.img : actor.data.img; // actor?.img; // Deprecated on 0.8.6
        }
        return "icons/svg/mystery-man.svg";
    }
    /**
     * Generate portrait HTML Image Element to insert into chat messages.
     * @param  {string} imgPath
     * @returns HTMLImageElement
     */
    static async generatePortraitImageElement(imgPath) {
        if (!imgPath) {
            return;
        }
        const img = document.createElement('img');
        const size = this.settings.portraitSize;
        // Support for video or webm file
        //let thumb = diff.img;
        //if (VideoHelper.hasVideoExtension(diff.img))
        //    thumb = await ImageHelper.createThumbnail(diff.img, { width: 48, height: 48 });
        //let thumb = 'icons/svg/mystery-man.svg';
        try {
            let imgThumb = await ImageHelper.createThumbnail(imgPath, { width: size, height: size });
            if (imgPath.endsWith("webm")) {
                img.src = imgThumb.thumb;
                // If a url we need these anyway
                img.width = size;
                img.height = size;
            }
            else {
                img.src = imgThumb.src;
                // If a url we need these anyway
                img.width = size;
                img.height = size;
            }
        }
        catch {
            img.src = imgPath;
            img.width = size;
            img.height = size;
        }
        img.classList.add("message-portrait");
        return img;
    }
    /**
     * Set portrait image border shape
     * @param  {HTMLImageElement} img
     * @param  {string} authorColor
     */
    static setImageBorder(img, authorColor) {
        const borderShape = this.settings.borderShape;
        const borderWidth = this.settings.borderWidth;
        const borderColor = this.settings.useUserColorAsBorderColor ? authorColor : this.settings.borderColor;
        switch (borderShape) {
            case 'square':
                img.style.border = `${borderWidth}px solid ${borderColor}`;
                break;
            case 'circle':
                img.style.border = `${borderWidth}px solid ${borderColor}`;
                img.style.borderRadius = '50%';
                break;
            case 'none':
                img.style.border = 'none';
                break;
        }
    }
    /**
     * Set the background color of the entire message to be the color for the author.
     * Only do so if
     *  - chatBackgroundColor setting is true AND
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     * @param  {string} authorColor
     */
    static setChatMessageBackground(html, messageData, authorColor) {
        const useUserBackgroundColor = this.settings.useUserColorAsChatBackgroundColor;
        if (useUserBackgroundColor) {
            html[0].setAttribute('style', 'background-color:' + authorColor + ';background-blend-mode:screen;');
        }
    }
    /**
     * Set the border color of the entire message to be the color for the author.
     * Only do so if
     *  - chatBorderColor setting is true AND
     *  - someone further up the chain hasn't already changed the color
     * @param  {JQuery} html
     * @param  {MessageRenderData} messageData
     * @param  {string} authorColor
     */
    static setChatMessageBorder(html, messageData, authorColor) {
        const useUserBorderColor = this.settings.useUserColorAsChatBorderColor;
        // only override the border color if someone further up the chain hasn't already done so.
        if (useUserBorderColor && !messageData.borderColor) {
            html[0].style.borderColor = authorColor;
            messageData.borderColor = authorColor;
        }
    }
    static get settings() {
        //return mergeObject(this.defaultSettings, <ChatPortraitSettings>game.settings.get(MODULE_NAME, 'settings'));
        //return mergeObject(this.defaultSettings,{
        return {
            //borderShapeList: Settings.getBorderShapeList(),
            useTokenImage: SettingsForm.getUseTokenImage(),
            useTokenName: SettingsForm.getUseTokenName(),
            portraitSize: SettingsForm.getPortraitSize(),
            portraitSizeItem: SettingsForm.getPortraitSizeItem(),
            borderShape: SettingsForm.getBorderShape(),
            useUserColorAsBorderColor: SettingsForm.getUseUserColorAsBorderColor(),
            borderColor: SettingsForm.getBorderColor(),
            borderWidth: SettingsForm.getBorderWidth(),
            useUserColorAsChatBackgroundColor: SettingsForm.getUseUserColorAsChatBackgroundColor(),
            useUserColorAsChatBorderColor: SettingsForm.getUseUserColorAsChatBorderColor(),
            flavorNextToPortrait: SettingsForm.getFlavorNextToPortrait(),
            forceNameSearch: SettingsForm.getForceNameSearch(),
            hoverTooltip: SettingsForm.getHoverTooltip(),
            textSizeName: SettingsForm.getTextSizeName(),
            displaySetting: SettingsForm.getDisplaySetting(),
            useAvatarImage: SettingsForm.getUseAvatarImage(),
            displayPlayerName: SettingsForm.getDisplayPlayerName(),
            displayUnknown: SettingsForm.getDisplayUnknown(),
            displayUnknownPlaceHolderActorName: SettingsForm.getDisplayUnknownPlaceHolderActorName(),
            displayUnknownPlaceHolderItemName: SettingsForm.getDisplayUnknownPlaceHolderItemName(),
            displayUnknownPlaceHolderItemIcon: SettingsForm.getDisplayUnknownPlaceHolderItemIcon(),
            displaySettingOTHER: SettingsForm.getDisplaySettingOTHER(),
            displaySettingOOC: SettingsForm.getDisplaySettingOOC(),
            displaySettingIC: SettingsForm.getDisplaySettingIC(),
            displaySettingEMOTE: SettingsForm.getDisplaySettingEMOTE(),
            displaySettingWHISPER: SettingsForm.getDisplaySettingWHISPER(),
            displaySettingROLL: SettingsForm.getDisplaySettingROLL(),
            displaySettingWhisperToOther: SettingsForm.getDisplaySettingWhisperToOther(),
        };
    }
    /**
     * Get default settings object.
     * @returns ChatPortraitSetting
     */
    static get defaultSettings() {
        return {
            useTokenImage: false,
            useTokenName: false,
            portraitSize: 36,
            portraitSizeItem: 36,
            borderShape: 'square',
            useUserColorAsBorderColor: true,
            borderColor: '#000000',
            borderWidth: 2,
            useUserColorAsChatBackgroundColor: false,
            useUserColorAsChatBorderColor: false,
            flavorNextToPortrait: false,
            forceNameSearch: false,
            hoverTooltip: false,
            textSizeName: 0,
            displaySetting: 'allCards',
            useAvatarImage: false,
            displayPlayerName: false,
            displayUnknown: 'none',
            displayUnknownPlaceHolderActorName: 'Unknown Actor',
            displayUnknownPlaceHolderItemName: 'Unknown Item',
            displayUnknownPlaceHolderItemIcon: `/modules/${MODULE_NAME}/assets/inv-unidentified.png`,
            displaySettingOTHER: true,
            displaySettingOOC: true,
            displaySettingIC: true,
            displaySettingEMOTE: true,
            displaySettingWHISPER: true,
            displaySettingROLL: true,
            displaySettingWhisperToOther: false,
        };
    }
    // /**
    //  * Load the appropriate actor image path for a given message, leveraging token or actor or actor search.
    //  * @param  {{scene?:string;actor?:string;token?:string;alias?:string;}} speaker
    //  * @returns string
    //  */
    //  static loadItemImagePathForChatMessage(speaker: {
    //   scene?: string;
    //   item?: string;
    //   token?: string;
    //   alias?: string;
    // }): string {
    //     if (!speaker.token && !speaker.actor) return;
    //     const useTokenImage: boolean = this.settings.useTokenImage;
    //     let item: Item;
    //     if (speaker.token) {
    //         item = game.actors.tokens[speaker.token];
    //         if (!item) {
    //             const tokenData = game.scenes.get(speaker.scene)?.data?.tokens?.find(t => t._id === speaker.token);
    //             if (useTokenImage && tokenData?.img) {
    //                 return tokenData.img;
    //             } else if (!useTokenImage && tokenData?.actorData?.img) {
    //                 return tokenData.actorData.img;
    //             }
    //         }
    //     }
    //     if (!item) {
    //         item  = game.actors.get(speaker.actor);
    //     }
    //     const forceNameSearch = this.settings.forceNameSearch;
    //     if (!item  && forceNameSearch) {
    //         item  = game.actors.find((a: Item) => a.name === speaker.alias);
    //     }
    //     return useTokenImage ? item?.data?.token?.img : item?.img;
    // }
    // static getSpeakerImage = function (message):string {
    //   const speaker = message.speaker;
    //   if (speaker) {
    //       if (speaker.token && this.settings.useTokenImage) {
    //           //@ts-ignore
    //           const token = getCanvas()?.tokens?.getDocuments().get(speaker.token);
    //           if (token) {
    //               return token.data.img;
    //           }
    //       }
    //       if (speaker.actor && !this.settings.useTokenImage) {
    //           const actor = Actors.instance.get(speaker.actor);
    //           if (actor) {
    //             //@ts-ignore
    //             return actor.data.img;
    //           }
    //       }
    //   }
    //   return "icons/svg/mystery-man.svg";
    // }
    // static showSpeakerImage = function (message):boolean {
    //   const speaker = message.speaker;
    //   if (!speaker) {
    //       return false;
    //   } else {
    //     let bHasImage = false;
    //     if (speaker.token && this.settings.useTokenImage) {
    //         //@ts-ignore
    //         const token = getCanvas()?.tokens?.getDocuments().get(speaker.token);
    //         if (token) {
    //             bHasImage = bHasImage || token.data.img != null;
    //         }
    //     }
    //     if (speaker.actor) {
    //         const actor = Actors.instance.get(speaker.actor);
    //         if (actor) {
    //             //@ts-ignore
    //             bHasImage = bHasImage || actor.data.img != null;
    //         }
    //     }
    //     if (!bHasImage) {
    //         return false;
    //     }else{
    //       return true;
    //     }
    //   }
    // }
    static getActor(speaker) {
        let actor = game.actors.get(speaker.actor);
        if (!actor) {
            actor = game.actors.tokens[speaker.token];
        }
        if (!actor) {
            //actor = game.actors.get(speaker.actor); // Deprecated on 0.8.6
            actor = Actors.instance.get(speaker.actor);
        }
        const forceNameSearch = this.settings.forceNameSearch;
        if (!actor && forceNameSearch) {
            actor = game.actors.find((a) => a.name === speaker.alias);
        }
        return actor;
    }
}
ChatPortrait.getActorName = function (speaker) {
    const actor = ChatPortrait.getActor(speaker); //game.actors.get(speaker.actor);
    if (actor) {
        return actor.name;
    }
    return speaker.alias;
};
ChatPortrait.getTokenName = function (speaker) {
    if (speaker.token) {
        const token = ChatPortrait.getToken(speaker.scene, speaker.token);
        if (token) {
            return token.name;
        }
    }
    const actor = game.actors.get(speaker.actor);
    if (actor) {
        if (actor.data.token) {
            return actor.data.token.name;
        }
        if (actor.hasPlayerOwner) {
            return actor.name;
        }
    }
    if (game.user.isGM) {
        return speaker.alias;
    }
    return this.settings.displayUnknownPlaceHolderActorName; //'???';
};
ChatPortrait.getToken = function (sceneID, tokenID) {
    const specifiedScene = game.scenes.get(sceneID);
    if (specifiedScene) {
        return ChatPortrait.getTokenForScene(specifiedScene, tokenID);
    }
    let foundToken = null;
    game.scenes.find((scene) => {
        foundToken = ChatPortrait.getTokenForScene(scene, tokenID);
        return !!foundToken;
    });
    return foundToken;
};
ChatPortrait.getTokenForScene = function (scene, tokenID) {
    if (!scene) {
        return null;
    }
    return scene.data.tokens.find((token) => {
        return token.id === tokenID;
    });
};
ChatPortrait.isSpeakerGM = function (message) {
    if (message.user) {
        let user = game.users.get(message.user);
        if (!user) {
            user = game.users.get(message.user.id);
        }
        if (user) {
            return user.isGM;
        }
        else {
            return false;
        }
    }
    return false;
};
ChatPortrait.shouldOverrideMessageUnknown = function (message) {
    const speaker = message.message.speaker;
    const actor = ChatPortrait.getActor(speaker);
    const setting = game.settings.get(MODULE_NAME, "displayUnknown");
    if (setting !== "none") {
        //const user = game.users.get(message.user);
        let user = game.users.get(message.user);
        if (!user) {
            user = game.users.get(message.user.id);
        }
        if (user) {
            const isSelf = user.data._id === game.user.data._id;
            const isGM = user.isGM;
            if ((setting === "allCards")
                || (setting === "self" && isSelf)
                || (setting === "selfAndGM" && (isSelf || isGM))
                || (setting === "gm" && isGM)
                || (setting === "player" && !isGM)
                || (setting === "onlyNpc" && actor?.data?.type == "npc" && !isGM)) {
                return true;
            }
        }
    }
    return false;
};
ChatPortrait.shouldOverrideMessageStyling = function (message) {
    const setting = game.settings.get(MODULE_NAME, "displaySetting");
    if (setting !== "none") {
        //const user = game.users.get(message.user);
        let user = game.users.get(message.user);
        if (!user) {
            user = game.users.get(message.user.id);
        }
        if (user) {
            const isSelf = user.data._id === game.user.data._id;
            const isGM = user.isGM;
            if ((setting === "allCards")
                || (setting === "self" && isSelf)
                || (setting === "selfAndGM" && (isSelf || isGM))
                || (setting === "gm" && isGM)
                || (setting === "player" && !isGM)) {
                return true;
            }
        }
    }
    return false;
};
ChatPortrait.getUserColor = function (message) {
    if (ChatPortrait.shouldOverrideMessageUnknown(message)) {
        //const user = game.users.get(message.user);
        let user = game.users.get(message.user);
        if (!user) {
            user = game.users.get(message.user.id);
        }
        return user.data.color;
    }
    return "";
};
ChatPortrait.getUserAvatar = function (message) {
    if (ChatPortrait.shouldOverrideMessageUnknown(message)) {
        //const user = game.users.get(message.user);
        let user = game.users.get(message.user);
        if (!user) {
            user = game.users.get(message.user.id);
        }
        if (user.data.avatar) { // image path
            return user.data.avatar;
        }
        else {
            return null;
        }
    }
    return null;
};
ChatPortrait.isWhisperToOther = function (speakerInfo) {
    const whisper = speakerInfo.message.whisper;
    //if (e.data.blind && e.data.whisper.find(element => element == game.userId) == undefined) return false;
    return whisper && whisper.length > 0 && whisper.indexOf(game.userId) === -1;
};
ChatPortrait.replaceSenderWithTokenName = function (messageSenderElem, speakerInfo) {
    const speaker = speakerInfo.message.speaker;
    const actorName = (ChatPortrait.getActorName(speaker) || '').trim();
    const name = (ChatPortrait.getTokenName(speaker) || '').trim();
    if (actorName !== name) {
        ChatPortrait.replaceMatchingTextNodes(messageSenderElem[0], actorName, name);
    }
};
ChatPortrait.replaceMatchingTextNodes = function (parent, match, replacement) {
    if (!parent || !parent.hasChildNodes()) {
        return;
    }
    for (let node of parent.childNodes) {
        if (node.nodeType === Node.TEXT_NODE) {
            if (node.wholeText.trim() === match) {
                node.parentNode.replaceChild(document.createTextNode(replacement), node);
            }
        }
        else {
            ChatPortrait.replaceMatchingTextNodes(node, match, replacement);
        }
    }
};
ChatPortrait.appendPlayerName = function (messageSenderElem, author) {
    const playerName = author.name;
    const playerNameElem = document.createElement('span');
    playerNameElem.appendChild(document.createTextNode(playerName));
    playerNameElem.classList.add(MODULE_NAME + '-playerName');
    messageSenderElem.append(playerNameElem);
};
ChatPortrait.getMessageTypeVisible = function (speakerInfo) {
    const messageType = speakerInfo.message.type;
    switch (messageType) {
        case CONST.CHAT_MESSAGE_TYPES.OTHER:
            return CONST.CHAT_MESSAGE_TYPES.OTHER;
        case CONST.CHAT_MESSAGE_TYPES.OOC:
            return CONST.CHAT_MESSAGE_TYPES.OOC;
        case CONST.CHAT_MESSAGE_TYPES.IC:
            return CONST.CHAT_MESSAGE_TYPES.IC;
        case CONST.CHAT_MESSAGE_TYPES.EMOTE:
            return CONST.CHAT_MESSAGE_TYPES.EMOTE;
        case CONST.CHAT_MESSAGE_TYPES.WHISPER:
            return CONST.CHAT_MESSAGE_TYPES.WHISPER;
        case CONST.CHAT_MESSAGE_TYPES.ROLL:
            return CONST.CHAT_MESSAGE_TYPES.ROLL;
        default:
            // "Unknown tab
            return;
    }
    return; // if there is some future new message type, its probably better to default to be visible than to hide it.
};
