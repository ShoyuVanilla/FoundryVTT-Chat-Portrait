import { MODULE_NAME } from "./settings.js";
export let ImageReplacerImpl = {};
/**
 * based on https://github.com/game-icons/icons/issues/516
 */
export const ImageReplacerInit = function () {
    // if(game.i18n.lang=="en"){
    //     ImageReplacerImpl = imageReplacerEn;
    // }
    // else if(game.i18n.lang=="ko"){
    //     ImageReplacerImpl = imageReplacerKo;
    // }
    // // TODO OTHER LANGUAGE
    // else{
    //     ImageReplacerImpl = imageReplacerEn;
    // }
    ImageReplacerImpl = imageReplacerUniversal;
    return ImageReplacerImpl;
};
export const imageReplacerUniversal = {
    // =======================================================================
    // dnd5e
    // =======================================================================
    "DND5E.DamageRoll": `/modules/${MODULE_NAME}/assets/damage_roll.svg`,
    "DND5E.AttackRoll": `/modules/${MODULE_NAME}/assets/attack_roll.svg`,
    "DND5E.AbilityStr": `/modules/${MODULE_NAME}/assets/strength.svg`,
    "DND5E.AbilityDex": `/modules/${MODULE_NAME}/assets/dexterity.svg`,
    "DND5E.AbilityCon": `/modules/${MODULE_NAME}/assets/constitution.svg`,
    "DND5E.AbilityInt": `/modules/${MODULE_NAME}/assets/intelligence.svg`,
    "DND5E.AbilityWis": `/modules/${MODULE_NAME}/assets/wisdom.svg`,
    "DND5E.AbilityCha": `/modules/${MODULE_NAME}/assets/charisma.svg`,
    "DND5E.Initiative": `/modules/${MODULE_NAME}/assets/initiative.svg`,
    "DND5E.SkillAcr": `/modules/${MODULE_NAME}/assets/acrobatics.svg`,
    "DND5E.SkillAni": `/modules/${MODULE_NAME}/assets/animal_handling.svg`,
    "DND5E.SkillArc": `/modules/${MODULE_NAME}/assets/arcana.svg`,
    "DND5E.SkillAth": `/modules/${MODULE_NAME}/assets/athletics.svg`,
    "DND5E.SkillDec": `/modules/${MODULE_NAME}/assets/deception.svg`,
    "DND5E.SkillHis": `/modules/${MODULE_NAME}/assets/history.svg`,
    "DND5E.SkillIns": `/modules/${MODULE_NAME}/assets/insight.svg`,
    "DND5E.SkillItm": `/modules/${MODULE_NAME}/assets/intimidation.svg`,
    "DND5E.SkillInv": `/modules/${MODULE_NAME}/assets/investigation.svg`,
    "DND5E.SkillMed": `/modules/${MODULE_NAME}/assets/medicine.svg`,
    "DND5E.SkillNat": `/modules/${MODULE_NAME}/assets/nature.svg`,
    "DND5E.SkillPrc": `/modules/${MODULE_NAME}/assets/perception.svg`,
    "DND5E.SkillPrf": `/modules/${MODULE_NAME}/assets/performance.svg`,
    "DND5E.SkillPer": `/modules/${MODULE_NAME}/assets/persuasion.svg`,
    "DND5E.SkillRel": `/modules/${MODULE_NAME}/assets/religion.svg`,
    "DND5E.SkillSlt": `/modules/${MODULE_NAME}/assets/sleight_of_hand.svg`,
    "DND5E.SkillSte": `/modules/${MODULE_NAME}/assets/stealth.svg`,
    "DND5E.SkillSur": `/modules/${MODULE_NAME}/assets/survival.svg`,
    "DND5E.ToolArtisans": `/modules/${MODULE_NAME}/assets/artisan_s_tools.svg`,
    "DND5E.ToolDisguiseKit": `/modules/${MODULE_NAME}/assets/disguise_kit.svg`,
    "DND5E.ToolForgeryKit": `/modules/${MODULE_NAME}/assets/forgery_kit`,
    "DND5E.ToolGamingSet": `/modules/${MODULE_NAME}/assets/gaming_set.svg`,
    "DND5E.ToolHerbalismKit": `/modules/${MODULE_NAME}/assets/herbalism_kit`,
    "DND5E.ToolMusicalInstrument": `/modules/${MODULE_NAME}/assets/musical_instrument.svg`,
    "DND5E.ToolNavigators": `/modules/${MODULE_NAME}/assets/navigator_s_tools.svg`,
    "DND5E.ToolPoisonersKit": `/modules/${MODULE_NAME}/assets/poisoner_s_kit.svg`,
    "DND5E.ToolThieves": `/modules/${MODULE_NAME}/assets/thieves_tools.svg`,
    "DND5E.ShortRest": `/modules/${MODULE_NAME}/assets/short_rest.svg`,
    "DND5E.LongRest": `/modules/${MODULE_NAME}/assets/long_rest.svg`, // https://game-icons.net/1x1/delapouite/person-in-bed.html
    // TODO
    // "DND5E.DamageAcid": `/modules/${MODULE_NAME}/assets/acid.svg`,
    // "DND5E.DamageBludgeoning": `/modules/${MODULE_NAME}/assets/bludgeoning.svg`,
    // "DND5E.DamageCold": `/modules/${MODULE_NAME}/assets/cold.svg`,
    // "DND5E.DamageFire": `/modules/${MODULE_NAME}/assets/fire.svg`,
    // "DND5E.DamageForce": `/modules/${MODULE_NAME}/assets/force.svg`,
    // "DND5E.DamageLightning": `/modules/${MODULE_NAME}/assets/lightning.svg`,
    // "DND5E.DamageNecrotic": `/modules/${MODULE_NAME}/assets/necrotic.svg`,
    // "DND5E.DamagePiercing": `/modules/${MODULE_NAME}/assets/piercing.svg`,
    // "DND5E.DamagePhysical": `/modules/${MODULE_NAME}/assets/non_magical_physical.svg`,
    // "DND5E.DamagePoison": `/modules/${MODULE_NAME}/assets/poison.svg`,
    // "DND5E.DamagePsychic": `/modules/${MODULE_NAME}/assets/psychic.svg`,
    // "DND5E.DamageRadiant": `/modules/${MODULE_NAME}/assets/radiant.svg`,
    // "DND5E.DamageSlashing": `/modules/${MODULE_NAME}/assets/slashing.svg`,
    // "DND5E.DamageThunder": `/modules/${MODULE_NAME}/assets/thunder.svg`,
    // "DND5E.DeathSave": `/modules/${MODULE_NAME}/assets/death_saves.svg`,
    // "DND5E.ConBlinded": "Blinded",
    // "DND5E.ConCharmed": "Charmed",
    // "DND5E.ConDeafened": "Deafened",
    // "DND5E.ConDiseased": "Diseased",
    // "DND5E.ConExhaustion": "Exhaustion",
    // "DND5E.ConFrightened": "Frightened",
    // "DND5E.ConGrappled": "Grappled",
    // "DND5E.ConImm": "Condition Immunities",
    // "DND5E.ConIncapacitated": "Incapacitated",
    // "DND5E.ConInvisible": "Invisible",
    // "DND5E.ConParalyzed": "Paralyzed",
    // "DND5E.ConPetrified": "Petrified",
    // "DND5E.ConPoisoned": "Poisoned",
    // "DND5E.ConProne": "Prone",
    // "DND5E.ConRestrained": "Restrained",
    // "DND5E.ConStunned": "Stunned",
    // "DND5E.ConUnconscious": "Unconscious",
    // "DND5E.Concentration": "Concentration",
};
export const imageReplacerDamageType = {
    "DND5E.DamageAcid": `/modules/${MODULE_NAME}/assets/acid.svg`,
    "DND5E.DamageBludgeoning": `/modules/${MODULE_NAME}/assets/bludgeoning.svg`,
    "DND5E.DamageCold": `/modules/${MODULE_NAME}/assets/cold.svg`,
    "DND5E.DamageFire": `/modules/${MODULE_NAME}/assets/fire.svg`,
    "DND5E.DamageForce": `/modules/${MODULE_NAME}/assets/force.svg`,
    "DND5E.DamageLightning": `/modules/${MODULE_NAME}/assets/lightning.svg`,
    "DND5E.DamageNecrotic": `/modules/${MODULE_NAME}/assets/necrotic.svg`,
    "DND5E.DamagePiercing": `/modules/${MODULE_NAME}/assets/piercing.svg`,
    "DND5E.DamagePhysical": `/modules/${MODULE_NAME}/assets/non_magical_physical.svg`,
    "DND5E.DamagePoison": `/modules/${MODULE_NAME}/assets/poison.svg`,
    "DND5E.DamagePsychic": `/modules/${MODULE_NAME}/assets/psychic.svg`,
    "DND5E.DamageRadiant": `/modules/${MODULE_NAME}/assets/radiant.svg`,
    "DND5E.DamageSlashing": `/modules/${MODULE_NAME}/assets/slashing.svg`,
    "DND5E.DamageThunder": `/modules/${MODULE_NAME}/assets/thunder.svg`,
    "DND5E.DeathSave": `/modules/${MODULE_NAME}/assets/death_saves.svg`,
};
