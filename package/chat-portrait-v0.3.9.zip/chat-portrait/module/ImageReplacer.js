import { MODULE_NAME } from "./settings.js";
export let ImageReplacerImpl = {};
/**
 * based on https://github.com/game-icons/icons/issues/516
 */
export const ImageReplacerInit = function () {
    if (game.i18n.lang == "en") {
        ImageReplacerImpl = imageReplacerEn;
    }
    else if (game.i18n.lang == "ko") {
        ImageReplacerImpl = imageReplacerKo;
    }
    // TODO OTHER LANGUAGE
    else {
        ImageReplacerImpl = imageReplacerEn;
    }
    return ImageReplacerImpl;
};
export const imageReplacerEn = {
    "Damage Roll": `/modules/${MODULE_NAME}/assets/damage_roll.svg`,
    "Attack Roll": `/modules/${MODULE_NAME}/assets/attack_roll.svg`,
    // =======================================================================
    // dnd5e
    // =======================================================================
    "Strength": `/modules/${MODULE_NAME}/assets/strength.svg`,
    "Dexterity": `/modules/${MODULE_NAME}/assets/dexterity.svg`,
    "Constitution": `/modules/${MODULE_NAME}/assets/constitution.svg`,
    "Intelligence": `/modules/${MODULE_NAME}/assets/intelligence.svg`,
    "Wisdom": `/modules/${MODULE_NAME}/assets/wisdom.svg`,
    "Charisma": `/modules/${MODULE_NAME}/assets/charisma.svg`,
    "Initiative": `/modules/${MODULE_NAME}/assets/initiative.svg`,
    "Strength Check": `/modules/${MODULE_NAME}/assets/strength.svg`,
    "Dexterity Check": `/modules/${MODULE_NAME}/assets/dexterity.svg`,
    "Constitution Check": `/modules/${MODULE_NAME}/assets/constitution.svg`,
    "Intelligence Check": `/modules/${MODULE_NAME}/assets/intelligence.svg`,
    "Wisdom Check": `/modules/${MODULE_NAME}/assets/wisdom.svg`,
    "Charisma Check": `/modules/${MODULE_NAME}/assets/charisma.svg`,
    "Initiative Check": `/modules/${MODULE_NAME}/assets/initiative.svg`,
    "Strength Save": `/modules/${MODULE_NAME}/assets/strength.svg`,
    "Dexterity Save": `/modules/${MODULE_NAME}/assets/dexterity.svg`,
    "Constitution Save": `/modules/${MODULE_NAME}/assets/constitution.svg`,
    "Intelligence Save": `/modules/${MODULE_NAME}/assets/intelligence.svg`,
    "Wisdom Save": `/modules/${MODULE_NAME}/assets/wisdom.svg`,
    "Charisma Save": `/modules/${MODULE_NAME}/assets/charisma.svg`,
    "Initiative Save": `/modules/${MODULE_NAME}/assets/initiative.svg`,
    "Acrobatics": `/modules/${MODULE_NAME}/assets/acrobatics.svg`,
    "Acrobatics Skill Check": `/modules/${MODULE_NAME}/assets/acrobatics.svg`,
    "Animal Handling": `/modules/${MODULE_NAME}/assets/animal_handling.svg`,
    "Animal Handling Skill Check": `/modules/${MODULE_NAME}/assets/animal_handling.svg`,
    "Arcana": `/modules/${MODULE_NAME}/assets/arcana.svg`,
    "Arcana Skill Check": `/modules/${MODULE_NAME}/assets/arcana.svg`,
    "Athletics": `/modules/${MODULE_NAME}/assets/athletics.svg`,
    "Athletics Skill Check": `/modules/${MODULE_NAME}/assets/athletics.svg`,
    "Deception": `/modules/${MODULE_NAME}/assets/deception.svg`,
    "Deception Skill Check": `/modules/${MODULE_NAME}/assets/deception.svg`,
    "History": `/modules/${MODULE_NAME}/assets/history.svg`,
    "History Skill Check": `/modules/${MODULE_NAME}/assets/history.svg`,
    "Insight": `/modules/${MODULE_NAME}/assets/insight.svg`,
    "Insight Skill Check": `/modules/${MODULE_NAME}/assets/insight.svg`,
    "Intimidation": `/modules/${MODULE_NAME}/assets/intimidation.svg`,
    "Intimidation Skill Check": `/modules/${MODULE_NAME}/assets/intimidation.svg`,
    "Investigation": `/modules/${MODULE_NAME}/assets/investigation.svg`,
    "Investigation Skill Check": `/modules/${MODULE_NAME}/assets/investigation.svg`,
    "Medicine": `/modules/${MODULE_NAME}/assets/medicine.svg`,
    "Medicine Skill Check": `/modules/${MODULE_NAME}/assets/medicine.svg`,
    "Nature": `/modules/${MODULE_NAME}/assets/nature.svg`,
    "Nature Skill Check": `/modules/${MODULE_NAME}/assets/nature.svg`,
    "Perception": `/modules/${MODULE_NAME}/assets/perception.svg`,
    "Perception Skill Check": `/modules/${MODULE_NAME}/assets/perception.svg`,
    "Performance": `/modules/${MODULE_NAME}/assets/performance.svg`,
    "Performance Skill Check": `/modules/${MODULE_NAME}/assets/performance.svg`,
    "Persuasion": `/modules/${MODULE_NAME}/assets/persuasion.svg`,
    "Persuasion Skill Check": `/modules/${MODULE_NAME}/assets/persuasion.svg`,
    "Religion": `/modules/${MODULE_NAME}/assets/religion.svg`,
    "Religion Skill Check": `/modules/${MODULE_NAME}/assets/religion.svg`,
    "Sleight of Hand": `/modules/${MODULE_NAME}/assets/sleight_of_hand.svg`,
    "Sleight of Hand Skill Check": `/modules/${MODULE_NAME}/assets/sleight_of_hand.svg`,
    "Stealth": `/modules/${MODULE_NAME}/assets/stealth.svg`,
    "Stealth Skill Check": `/modules/${MODULE_NAME}/assets/stealth.svg`,
    "Survival": `/modules/${MODULE_NAME}/assets/survival.svg`,
    "Survival Skill Check": `/modules/${MODULE_NAME}/assets/survival.svg`,
    "Artisan's Tools": `/modules/${MODULE_NAME}/assets/artisan_s_tools.svg`,
    "Disguise Kit": `/modules/${MODULE_NAME}/assets/disguise_kit.svg`,
    "Forgery Kit": `/modules/${MODULE_NAME}/assets/forgery_kit`,
    "Gaming Set": `/modules/${MODULE_NAME}/assets/gaming_set.svg`,
    "Herbalism Kit": `/modules/${MODULE_NAME}/assets/herbalism_kit`,
    "Musical Instrument": `/modules/${MODULE_NAME}/assets/musical_instrument.svg`,
    "Navigator's tools": `/modules/${MODULE_NAME}/assets/navigator_s_tools.svg`,
    "Poisoner's Kit": `/modules/${MODULE_NAME}/assets/poisoner_s_kit.svg`,
    "Thieves Tools": `/modules/${MODULE_NAME}/assets/thieves_tools.svg`,
    "Thieves' Tools": `/modules/${MODULE_NAME}/assets/thieves_tools.svg`,
    "Short Rest": `/modules/${MODULE_NAME}/assets/short_rest.svg`,
    "Long Rest": `/modules/${MODULE_NAME}/assets/long_rest.svg`, // https://game-icons.net/1x1/delapouite/person-in-bed.html
};
export const imageReplacerKo = {
// =======================================================================
// dnd5e
// =======================================================================
};
