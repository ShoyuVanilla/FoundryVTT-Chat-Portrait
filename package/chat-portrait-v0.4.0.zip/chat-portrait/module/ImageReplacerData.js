export class ImageReplacerData {
}
