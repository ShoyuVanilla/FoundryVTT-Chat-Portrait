export class ImageReplacerData {
    constructor() {
        this.iconMain = "";
        this.iconsDamageType = new Array();
    }
}
