export class ImageReplacerData {
    constructor() {
        this.iconMainReplacer = "";
        this.iconsDamageType = new Array();
    }
}
export class ChatPortraitCustomData {
    constructor() {
        this.iconMainCustomImage = "";
        this.iconMainCustomReplacer = "";
    }
}
