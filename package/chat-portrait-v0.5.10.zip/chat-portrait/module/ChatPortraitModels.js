export class ImageReplacerData {
    constructor() {
        this.iconMainReplacer = '';
        this.iconsDamageType = [];
    }
}
export class ChatPortraitCustomData {
    constructor() {
        this.customIconPortraitImage = '';
    }
}
