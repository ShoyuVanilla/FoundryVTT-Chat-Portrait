import { i18n } from "../main.js";
import { ChatPortrait } from "./ChatPortrait.js";
import { MODULE_NAME } from "./settings.js";
export class ChatPortraitForm extends FormApplication {
    constructor() {
        super();
    }
    static get defaultOptions() {
        //@ts-ignore
        return mergeObject(super.defaultOptions, {
            title: i18n(MODULE_NAME + '.form-title'),
            id: 'chat-portrait-form',
            template: `modules/${MODULE_NAME}/templates/chat-portrait-form.html`,
            width: 500,
            closeOnSubmit: true
        });
    }
    getData(options) {
        //@ts-ignore
        return mergeObject(super.getData(), {
            //@ts-ignore
            borderShapeList: {
                'square': i18n(MODULE_NAME + '.square'),
                'circle': i18n(MODULE_NAME + '.circle'),
                'none': i18n(MODULE_NAME + '.none')
            }
        }, this.reset ? ChatPortrait.defaultSettings :
            mergeObject(ChatPortrait.defaultSettings, game.settings.get(MODULE_NAME, 'settings')));
    }
    activateListeners(html) {
        super.activateListeners(html);
        this.toggleBorderShape();
        this.toggleUseUserColorAsBorderColor();
        html.find('select[name="borderShape"]').change(this.toggleBorderShape.bind(this));
        html.find('input[name="useUserColorAsBorderColor"]').change(this.toggleUseUserColorAsBorderColor.bind(this));
        html.find('input[name="useUserColorAsBackgroundColor"]').change(this.toggleUseUserColorAsBackgroundColor.bind(this));
        html.find('button[name="reset"]').click(this.onReset.bind(this));
        this.reset = false;
    }
    toggleBorderShape() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBorderColor"]')[0].checked;
        $('input[name="useUserColorAsBorderColor"]').prop("disabled", noneBorder);
        $('input[name="useUserColorAsBackgroundColor"]').prop("disabled", noneBorder);
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderWidth"]').prop("disabled", noneBorder);
    }
    toggleUseUserColorAsBorderColor() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBorderColor"]')[0].checked;
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
    }
    toggleUseUserColorAsBackgroundColor() {
        const noneBorder = $('select[name="borderShape"]').val() === 'none';
        const useUserColor = $('input[name="useUserColorAsBackgroundColor"]')[0].checked;
        $('input[name="borderColor"]').prop("disabled", noneBorder || useUserColor);
        $('input[name="borderColorSelector"]').prop("disabled", noneBorder || useUserColor);
    }
    onReset() {
        this.reset = true;
        this.render();
    }
    async _updateObject(event, formData) {
        let settings = mergeObject(ChatPortrait.settings, formData, { insertKeys: false, insertValues: false });
        await game.settings.set(MODULE_NAME, 'settings', settings);
    }
}
